package service;

public class ScheduleService {

}
